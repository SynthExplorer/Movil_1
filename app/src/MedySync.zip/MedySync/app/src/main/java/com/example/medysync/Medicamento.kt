package com.example.medysync

data class Medicamento(
    val nombre: String,
    val dosis: String,
    val tipo: String,
    val duracion: String
)
