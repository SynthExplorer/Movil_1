package com.example.medysync

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MedicamentoAdapter
    private val listaMedicamentos = mutableListOf<Medicamento>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        adapter = MedicamentoAdapter(listaMedicamentos)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        findViewById<FloatingActionButton>(R.id.fabAgregar).setOnClickListener {
            mostrarDialogoAgregar()
        }
    }

    private fun mostrarDialogoAgregar() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_agregar_medicamento, null)
        val etNombre = dialogView.findViewById<EditText>(R.id.etNombre)
        val etDosis = dialogView.findViewById<EditText>(R.id.etDosis)
        val spinnerTipo = dialogView.findViewById<Spinner>(R.id.spinnerTipo)

        val contadorAnios = dialogView.findViewById<NumberPicker>(R.id.contadorAnios)
        val contadorMeses = dialogView.findViewById<NumberPicker>(R.id.contadorMeses)
        val contadorSemanas = dialogView.findViewById<NumberPicker>(R.id.contadorSemanas)
        val contadorDias = dialogView.findViewById<NumberPicker>(R.id.contadorDias)
        val contadorHoras = dialogView.findViewById<NumberPicker>(R.id.contadorHoras)

        contadorAnios.minValue = 0; contadorAnios.maxValue = 99
        contadorMeses.minValue = 0; contadorMeses.maxValue = 11
        contadorSemanas.minValue = 0; contadorSemanas.maxValue = 51
        contadorDias.minValue = 0; contadorDias.maxValue = 30
        contadorHoras.minValue = 0; contadorHoras.maxValue = 23


        val tiposMedicamentos = arrayOf("Tableta", "Cápsula", "Jarabe", "Inyección")
        spinnerTipo.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, tiposMedicamentos)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setPositiveButton("Agregar") { _, _ ->
                val nombre = etNombre.text.toString().trim()
                val dosis = etDosis.text.toString().trim()
                val tipo = spinnerTipo.selectedItem.toString()

                val duracion = String.format("%02d:%02d:%02d:%02d:%02d",
                    contadorAnios.value,
                    contadorMeses.value,
                    contadorSemanas.value,
                    contadorDias.value,
                    contadorHoras.value)

                if (nombre.isNotEmpty() && dosis.isNotEmpty()) {
                    adapter.agregarMedicamento(Medicamento(nombre, dosis, tipo, duracion))
                } else {
                    Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .create()
        dialog.show()
    }
}
