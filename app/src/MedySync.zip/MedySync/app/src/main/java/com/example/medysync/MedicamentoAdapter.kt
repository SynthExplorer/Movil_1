package com.example.medysync

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MedicamentoAdapter(private val lista: MutableList<Medicamento>) :
    RecyclerView.Adapter<MedicamentoAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvNombre: TextView = view.findViewById(R.id.tvNombre)
        val tvDosis: TextView = view.findViewById(R.id.tvDosis)
        val tvTipo: TextView = view.findViewById(R.id.tvTipo)
        val tvDuracion: TextView = view.findViewById(R.id.tvDuracion)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_medicamento, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val medicamento = lista[position]
        holder.tvNombre.text = medicamento.nombre
        holder.tvDosis.text = medicamento.dosis
        holder.tvTipo.text = medicamento.tipo
        holder.tvDuracion.text = "Duracion: ${medicamento.duracion}"
    }

    override fun getItemCount(): Int = lista.size

    fun agregarMedicamento(medicamento: Medicamento) {
        lista.add(medicamento)
        notifyItemInserted(lista.size - 1)
    }
}
